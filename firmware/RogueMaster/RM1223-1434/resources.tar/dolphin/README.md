
- Animations: Trimmed out the Flipper animations. `/ext/dolphin` folder on your Flipper should now be managed by you! [Copy this folder (RM Select)](https://github.com/RogueMaster/awesome-flipperzero-withModules/tree/rogue_main/dolphin-RMselect) or [this folder (RM minimal)](https://github.com/RogueMaster/awesome-flipperzero-withModules/tree/rogue_main/dolphin-minimal) if you don't want to do the work but want more animations.
- - Rename the [minimal animation file](https://github.com/RogueMaster/flipperzero-firmware-wPlugins/blob/420/assets/resources/dolphin/manifest.txt.exampleMin) to see it, or [RM select](https://github.com/RogueMaster/flipperzero-firmware-wPlugins/blob/420/assets/resources/dolphin/manifest.txt.exampleRM) if you have copied over [the RM select](https://github.com/RogueMaster/awesome-flipperzero-withModules/tree/rogue_main/dolphin-RMselect) animations.

- Not all of these animations are here, some are [here](https://github.com/RogueMaster/awesome-flipperzero-withModules/tree/rogue_main/dolphin-all)
- Assets: Includes New Dolphin Animations: [Rick Roll, Matrix & Swim animations (By qqMajiKpp)], [Rukamon 2x and Agumon animations (By Syrius)], [Mew (By Arkaivos)], [Eye of the Flipper (By Kuronons)], [Shodan (By qqMajiKpp)], [Sirene & The Witch (By Haseo)], [Dino & A New Hope (By Haseo)], [Earth Arcadia (By Kuronons)], [Kuronons Black Flags Collection (21 Animations)(By Kuronons)], [D.Va (By Haseo)], [GITS (By Haseo)], [Slayers (By qqMajiKpp)], [P0liwhirl (By Panzer00Z)], [RogueMaster CFW Animation (By Kuronons)], [Nyan Cat (By Haseo)], [L (By Kuronons)], [Laughing Man (By Kuronons)], [B0ws3r (By Haseo)], [Kuronons Black Flags Collection VOL 2 (9 Animations)(By Kuronons)], [Thanks for all the fish (By qqMajiKpp)], [OCP, Skynet and Weyland (By Kuronons)], [Mario (By Haseo)], [Umbrella (By Haseo)], [Trioptimum (By qqMajiKpp)], [Tyrell & Cyberdyne (By Kuronons)], [Allen & Maha (By Haseo)], [Starfield (By qqMajiKpp)], [DJ (By ut1s)], [Fireplace (By Friend of xMasterX)], [Akira & Mad Scientist (By qqMajiKpp)], [Shar!ngan (By Haseo)], [Lions Roar (By qqMajiKpp)], [0ne Pi3ce (By Haseo)], [Calcifier & Last Unicorn (By NeonKodama)], [Jiji Milk (By NeonKodama)], [Halloween, Hexadecimal, Init D Water, Kam3Ham3Ha, Kirbs, Kirbs Confused, M3gamanZ3r0 Battle, OP G3ar 4, Z3lda 0h & Zelda R3ady (By RogueMaster)], [Rekall (By Kuronons)], [Stick Fight (By Sasquach)], [G0ku, Lufy & Mug1wara (By Haseo)], [Tardi5 (By RogueMaster)] & [80s (By Haseo)]
- Assets: Includes New Dolphin Animations: [School Days, Whistper of the Heart and The Legend of Zelda (By stop_oxy]
- Assets: Includes New Dolphin Animations: [Rogue Master Custom Firmware (By Sasquach)]
- Assets: Includes New Dolphin Animations: [Veemon (By felix-two-tone)]
- Assets: Includes New Dolphin Animations: [G0ku (By Sasquach)]
- Assets: Includes New Dolphin Animations: [Aika Zer0, Aika Zer0 2, Kaz0ku Haha & P3ach Run (By RogueMaster)] (hidden)
- Assets: Includes New Dolphin Animations: [CloudG0ku (By Sasquach)]
- Assets: Includes New Dolphin Animations: [BulmFlash, G0ku Pat Pat and Sail0rM00n (By RogueMaster)] (hidden)
- Assets: Includes New Dolphin Animations: [ChiChi, G0ku Pew and R0shi (By RogueMaster)]
- Assets: Includes New Dolphin Animations: [Narut0 (By Sasquach)]
- Assets: Includes New Dolphin Animations: [Blaster (By Sasquach)]
- Assets: Includes New Dolphin Animations: [Flipper City (By Svaarich)]
- Unleashed PR [feature[animation]: purple rain animation #111 (By wotori)](https://github.com/DarkFlippers/unleashed-firmware/pull/111)
- Assets: Includes New Dolphin Animations: [D1g1talRa1n (By Sasquach)]


## REPOSITORIES FOR OTHER ANIMATION CREATORS:
## [Kuronons Flipper Animations](https://github.com/Kuronons/FZ_graphics)
## [Haseo Flipper Animations](https://github.com/Haseosama/FZ_Animations)
## [Talking-Sasquach Flipper Animations](https://github.com/skizzophrenic/Talking-Sasquach)
## [stopoxy Flipper Animations](https://github.com/stopoxy/FZAnimations)
## [HexxedBitHeadz Flipper Animations](https://github.com/HexxedBitHeadz/FlipperZeroWallpaper)
## [CharlesTheGreat77 Flipper Animations](https://github.com/CharlesTheGreat77/FlipperZeroAnimation)


## Some Previews Provided By Creators:




https://user-images.githubusercontent.com/16942638/193430832-d0e8c05f-62dc-420d-9879-5dd541a2d184.mp4



https://user-images.githubusercontent.com/16942638/193430846-d286baf4-95dd-4d40-af53-e5437726c71a.mp4



https://user-images.githubusercontent.com/16942638/193430850-19019756-92b2-4c47-b357-636a0385d49d.mp4
